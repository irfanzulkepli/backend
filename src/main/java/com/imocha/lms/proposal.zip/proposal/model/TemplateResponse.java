package com.imocha.lms.proposal.model;

import java.util.Date;

import lombok.Data;

@Data
public class TemplateResponse {

	private int id;
	private String title;
	private String content;
	private String status;

}
